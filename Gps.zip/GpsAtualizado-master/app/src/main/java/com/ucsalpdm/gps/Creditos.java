package com.ucsalpdm.gps;

import android.app.Activity;

public class Creditos extends Activity {
}
